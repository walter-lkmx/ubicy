<nav class="categories">
  <h2 class="title">Categorías</h2>
  <?php wp_list_categories() ?>
</nav>