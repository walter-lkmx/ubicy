<section class="featured">
  <?php include('featured-content.php'); ?>
</section>
<section class="categories">
  <?php include('categories.php'); ?>
</section>